﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB;
using System.IO;
using System.Windows.Forms;

namespace BabyTrainCopyModel
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class BatchFamilyExportImage_WPF : Window
    {
        /// <summary>
        /// 传入三个参数
        /// </summary>
        //各种参数
        public FileSystemInfo FamilyPath { get; set; }

        public DisplayStyle ViewDisplayStyle { get; set; }

        public ViewDetailLevel DetailLevel { get; set; }

        public int Scale { get; set; }

        public int ImagePixel { get; set; }

        public bool is_AllTwoD { get; set; }

        public bool is_HideHost { get; set; }

        public BatchFamilyExportImage_WPF()
        {
            InitializeComponent();
            //获取地址
            FamilyPath = PickFolderInfo();
           
            List<string> displayStyleList = new List<string>()
            {"线框","隐藏线","着色","一致的颜色","真实" };
            displayStyle.ItemsSource = displayStyleList;
            List<string> detailLevelList = new List<string>()
            {"粗略","详细","中等"};
            detailLevel.ItemsSource = detailLevelList;


        }

    

        private void Enter_Click(object sender, RoutedEventArgs e)
        {

            if (FamilyPath == null)
            {

                this.DialogResult = false;
                //this.Close();
            }
            Scale = int.Parse(scaleText.Text);

            ImagePixel = int.Parse(pixel.Text);

            is_AllTwoD =(bool) allTwoDCheckBox.IsChecked;

            is_HideHost = (bool)hideHost.IsChecked;

            //is_HideHost=(bool)
            
            switch (displayStyle.SelectedIndex) {
                case 0:
                    ViewDisplayStyle = DisplayStyle.Wireframe;
                    break;
                case 1:
                    ViewDisplayStyle = DisplayStyle.HLR;
                    break;
                case 2:
                    ViewDisplayStyle = DisplayStyle.ShadingWithEdges;
                    break;
                case 3:
                    ViewDisplayStyle = DisplayStyle.FlatColors;
                    break;
                case 4:
                    ViewDisplayStyle = DisplayStyle.RealisticWithEdges;
                    break;
            }

            switch (detailLevel.SelectedIndex) {
                case 0:
                    DetailLevel = ViewDetailLevel.Coarse;
                    break;
                case 1:
                    DetailLevel = ViewDetailLevel.Fine;
                    break;
                case 2:
                    DetailLevel = ViewDetailLevel.Medium;
                    break;
            }
            DialogResult = true;
            //this.Close();

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
       

            familyFilePath.Text = FamilyPath.FullName;
            displayStyle.SelectedIndex = 4;
            detailLevel.SelectedIndex = 2;

          
            
        }

        private void Path_Click(object sender, RoutedEventArgs e)
        {
            FamilyPath = PickFolderInfo();
            if (FamilyPath!=null) {
                familyFilePath.Text=
                FamilyPath.FullName;
            }

       
        }


        private FileSystemInfo PickFolderInfo()
        {
            FolderBrowserDialog dialog = new FolderBrowserDialog();
            dialog.Description = "请选择族文件所在地址";
            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                return new DirectoryInfo(dialog.SelectedPath);
            }
            return null;
        }
    }
}
