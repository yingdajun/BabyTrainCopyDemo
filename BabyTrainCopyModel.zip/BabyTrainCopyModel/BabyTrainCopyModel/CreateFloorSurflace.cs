﻿using System.Collections.Generic;
using System.Linq;
using Autodesk.Revit.UI;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.Attributes;
namespace BabyTrainCopyModel
{
    [Journaling(JournalingMode.UsingCommandData)]
    [Transaction(TransactionMode.Manual)]
    class CreateFloorSurflace : IExternalCommand
    {
        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            //初始化应用程序和文档
            UIDocument uidoc = commandData.Application.ActiveUIDocument;
            Document doc = uidoc.Document;
            try
            {
                //过滤房间
                List<Element> roomList = RoomList(doc);

                //如果模型没有房间，高显同时报错
                if (!(roomList.Count > 0))
                {
                    message = "模型没有绘制房间";
                    return Result.Failed;
                }

                //过滤楼板
                //楼板元素
                List<Element> floorList = FloorList(doc);
                if (!(floorList.Count > 0))
                {
                    message = "模型没有楼板类型";
                    return Result.Failed;
                }

                //弹出对话框,让用户选择要添加楼板的房间和楼板面层的类型

                List<string> createSetting = ShowDialog(roomList,floorList);
                if (!(createSetting.Count > 0))
                {
             
                    return Result.Cancelled;
                }

                //获取房间轮廓
                List<Element> roomsList = new List<Element>();
                //房间的轮廓元素
                List<CurveArray> curveArrayList = RoomBoundaryList(roomList,createSetting,out roomsList);
                //如果房间没有有有效元素报错
                if (!(curveArrayList.Count > 0))
                {
                    message = "模型没有有效轮廓";
                    return Result.Failed;
                }


                //生成楼板面层
                //TaskDialog.Show("1",createSetting[2]);

                FloorType ft = floorList.Where(x =>x.Name ==createSetting[2]).First() as FloorType;

                //TaskDialog.Show("1",ft.Name);

                bool result =
                CreateSurflace(doc, ft, curveArrayList,roomsList);


                if (result != true )
                {
                    message = "楼板面层绘制失败";
                    return Result.Failed;
                }
            }
            catch
            {
                //message = ex.Message;
                return Result.Cancelled;
            }

            return Result.Succeeded;
        }

        /// <summary>
        /// 过滤项目中所有的房间
        /// </summary>
        /// <param name="doc">当前项目对象</param>
        /// <returns>房间列表</returns>
        public  List<Element> RoomList(Document doc)
        {


            //throw new NotImplementedException();
            FilteredElementCollector roomCollector = new FilteredElementCollector(doc);

            roomCollector.OfCategory(BuiltInCategory.OST_Rooms).OfClass(typeof(SpatialElement));

            List<Element> roomList = roomCollector.ToList();

            return roomList;
        }
        /// <summary>
        /// 获取楼板
        /// </summary>
        /// <param name="doc"></param>
        /// <returns></returns>
        private List<Element> FloorList(Document doc)
        {
            //throw new NotImplementedException();
            FilteredElementCollector floorCollector = new FilteredElementCollector(doc);

            floorCollector.OfCategory(BuiltInCategory.OST_Floors).OfClass(typeof(FloorType));

            List<Element> floorList = floorCollector.ToList();

            return floorList;
        }
        /// <summary>
        /// 获取房间轮廓
        /// </summary>
        /// <param name="roomList"></param>
        /// <returns></returns>

        //跳出一个对话框,选择要生成墙体的房间和选择的楼板面层
        private List<string> ShowDialog(List<Element> roomList,List<Element> floorTypeList) {

            List<string> value = new List<string>();
            //转换形式
            List<Room> roomsList = roomList.ConvertAll(x => x as Room);

            List<string> parameterName = new List<string>();

            ParameterMap paraMap = roomList.First().ParametersMap;

            foreach (Parameter para in paraMap) {
                parameterName.Add(para.Definition.Name);
            }
            //转换形式
            List<string> floorTypesList = floorTypeList.ConvertAll(x => x.Name);


            CreateFloorSurflace_WPF wpf = new CreateFloorSurflace_WPF(
                parameterName,roomsList,floorTypesList);

            if (wpf.ShowDialog()==true) {

                //传递元素到后台去
                value.Add(wpf.parameterNameCombo.SelectedItem.ToString());
                value.Add(wpf.parameterValueCombo.SelectedItem.ToString());
                value.Add(wpf.floorTypeCombo.SelectedItem.ToString());
                return value;
            };
            return value;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="roomList">房间列表</param>
        /// <param name="createSetting"></param>
        /// <param name="roomToCreate"></param>
        /// <returns></returns>
        private List<CurveArray> RoomBoundaryList(List<Element> roomList, List<string> createSetting
            , out List<Element> roomToCreate)
        {
            //获取指定房间
            List<Element> roomsList = new List<Element>();
            //
            string paraName = createSetting[0];
            //
            string paraValue = createSetting[1];

            //如果不是全部生成
            if (paraValue != "全部生成")
            {
                //遍历房间列表
                foreach (Element ele in roomList)
                {
                    //所有房间参数
                    ParameterMap paraMap =ele.ParametersMap;
                    //遍历所有的参数
                    foreach (Parameter para in paraMap)
                    {
                        if (para.Definition.Name == paraName)
                        {
                            if (para.HasValue)
                            {
                                string value;
                                if (para.StorageType == StorageType.String)
                                {
                                    value = para.AsString();
                                }
                                else
                                {
                                    value = para.AsValueString();
                                }
                                if (value == paraValue)
                                {
                                    roomsList.Add(ele);
                                }
                            }

                        }

                    }

                }
            }
            else
            {
                roomsList = roomList;
            }

            //
            List<CurveArray> curveArrayList = new List<CurveArray>();
            //
            roomToCreate = new List<Element>();
            //
            foreach (Element element in roomsList)
            {
                Room room = element as Room;
                //存储房间最大轮廓
                CurveArray ca = new CurveArray();
                //用于判断房间最大轮廓
                List<CurveLoop> curveLoopList = new List<CurveLoop>();
                //获取房间边界
                IList<IList<BoundarySegment>> roomBoundaryListList =
                    room.GetBoundarySegments(new SpatialElementBoundaryOptions());

                //获取房间所有边界
                if (roomBoundaryListList != null)
                {
                    //获取房间所有封闭曲线
                    foreach (IList<BoundarySegment> roomBoundaryList in roomBoundaryListList)
                    {
                        CurveLoop curveLoop = new CurveLoop();
                        foreach (BoundarySegment roomBoundary in roomBoundaryList)
                        {
                            curveLoop.Append(roomBoundary.GetCurve());

                        }
                        curveLoopList.Add(curveLoop);
                    }
                }
                //
                if(roomBoundaryListList.Count==0)
                {
                    continue;
                }


                //拉伸曲线展开体积
                List<double> volumn = new List<double>();
                try
                {

                    foreach (CurveLoop curveLoop in curveLoopList)
                    {

                        IList<CurveLoop> cList = new List<CurveLoop>();

                        cList.Add(curveLoop);

                        Solid solid = GeometryCreationUtilities.
                            CreateExtrusionGeometry(cList, XYZ.BasisZ, 1);

                        volumn.Add(solid.Volume);
                    }

                }
                catch
                {
                    continue;
                }
         

                //体积最大的就是最大的LOOP

                CurveLoop LargeLoop = curveLoopList.ElementAt(volumn.IndexOf(volumn.Max()));

                //转换
                foreach (Curve curve in LargeLoop)
                {
                    ca.Append(curve);
                }
                //获取最大的轮廓
                curveArrayList.Add(ca);
                //
                roomToCreate.Add(element);
            }

            //
            return curveArrayList;
        }
        /// <summary>
        /// 生成楼板
        /// </summary>
        /// <param name="doc"></param>
        /// <param name="ft"></param>
        /// <param name="roomBoundaryList"></param>
        /// <returns></returns>
        private bool CreateSurflace(Document doc, FloorType ft, List<CurveArray> roomBoundaryList
            ,List<Element> roomsList)
        {
            double thick = ft.get_Parameter(BuiltInParameter.FLOOR_ATTR_DEFAULT_THICKNESS_PARAM).AsDouble();

            using (Transaction trans = new Transaction(doc, "生成楼板面层"))
            {
                trans.Start();

                //foreach (CurveArray ca in roomBoundaryList)
                for(int i=0;i<roomBoundaryList.Count;i++)
                {
                    Floor floor = doc.Create.NewFloor(roomBoundaryList[i],ft,doc.GetElement(roomsList[i].LevelId) as Level
                        , false);

                    floor.get_Parameter(BuiltInParameter.FLOOR_HEIGHTABOVELEVEL_PARAM).Set(thick);

                    floor.get_Parameter(BuiltInParameter.ALL_MODEL_MARK)
                        .Set(roomsList[i].get_Parameter(BuiltInParameter.ROOM_NUMBER).AsString());
                    roomsList[i].get_Parameter(BuiltInParameter.ROOM_FINISH_FLOOR)
                        .Set(ft.Name);
                }
                trans.Commit();
            }
            return true;
        }
    }
}
