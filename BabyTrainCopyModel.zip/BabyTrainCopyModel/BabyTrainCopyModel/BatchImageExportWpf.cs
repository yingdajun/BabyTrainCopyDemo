﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System.IO;
using System.Windows.Forms;

namespace BabyTrainCopyModel
{
    [Transaction(TransactionMode.Manual)]
    class BatchImageExportWpf : IExternalCommand
    {
        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            //初始化 //这是有界面版本
            UIApplication uiapp = commandData.Application;
            UIDocument uidoc = uiapp.ActiveUIDocument;
            Document doc = uidoc.Document;
            try {
                ////选择族文件路径
                //FileSystemInfo familyPath = PickFolderInfo();
                //if (familyPath == null)
                //{
                //    return Result.Failed;
                //}
                //弹出窗口，让用户设置导出设置
                BatchFamilyExportImage_WPF batchwpf = new BatchFamilyExportImage_WPF();
                if (batchwpf.FamilyPath==null) {
                    return Result.Cancelled;
                }
                if (batchwpf.ShowDialog()==false) {
                    return Result.Cancelled;
                }
                //获取族文件
                List<FileInfo> familyFileList = GetFamilyList(batchwpf.FamilyPath);
                if (familyFileList == null)
                {
                    return Result.Failed;
                }
                //导出族图片
                TaskDialog.Show("revit", "族图片地址为" + batchwpf.FamilyPath.ToString());
                bool result =
                ExportImage(uiapp,batchwpf,familyFileList);

                if (result != true)
                {
                    message = "族图片导出失败";
                    return Result.Failed;
                }

            } catch (Exception ex) {
                message = ex.Message;
                return Result.Failed;
            }
            //throw new NotImplementedException();
            return Result.Succeeded;
        }
        /// <summary>
        /// 获取族文件位置
        /// </summary>
        /// <returns></returns>
        private FileSystemInfo PickFolderInfo() {
            FolderBrowserDialog dialog = new FolderBrowserDialog();
            dialog.Description = "请选择族文件路径";
            if (dialog.ShowDialog()==DialogResult.OK) {
                return new DirectoryInfo(dialog.SelectedPath);
            }
            return null;
        }

        /// <summary>
        /// 获取所有的族文件
        /// </summary>
        /// <param name="familyPath"></param>
        /// <returns></returns>
        private List<FileInfo> GetFamilyList(FileSystemInfo familyPath)
        {
            //这里是个遍历操作，使得选定族文件夹下面所有的族都能导出
            List<FileInfo> familyList = new List<FileInfo>();
            if (!familyPath.Exists) return null;
            DirectoryInfo dir = familyPath as DirectoryInfo;
            if (dir == null) return null;
            familyList.AddRange(dir.GetFiles("*.rfa"));
            foreach (DirectoryInfo dInfo in dir.GetDirectories())
            {
                familyList.AddRange(GetFamilyList(dInfo));
            }
            return familyList;
        }


        private bool ExportImage(UIApplication uiapp, BatchFamilyExportImage_WPF batchwpf,
            List<FileInfo> familyFileList)
        {
            Document doc = null;
            foreach (FileInfo file in familyFileList)
            {
                UIDocument newUIDoc = uiapp.OpenAndActivateDocument(file.FullName);
                Document newDoc = newUIDoc.Document;
                if (doc != null)
                    doc.Close(false);
                doc = newDoc;
                FilteredElementCollector viewCollector = new FilteredElementCollector(newDoc);
                viewCollector.OfCategory(BuiltInCategory.OST_Views).OfClass(typeof(View3D));
                if (viewCollector.Count() == 0||batchwpf.is_AllTwoD)
                {
                    
                    TwoExportImage(newUIDoc, newDoc,batchwpf);
                   
                }
                else
                {
                    
                    ThreeExportImage(newUIDoc, newDoc, viewCollector,batchwpf);
                    
                }
               
                ImageExportOptions option = new ImageExportOptions();
                option.FilePath = file.FullName;
                option.ZoomType = ZoomFitType.FitToPage;
                option.PixelSize = batchwpf.ImagePixel;
                option.ImageResolution = ImageResolution.DPI_300;
                //option.ImageResolution = ImageResolution.DPI_300;
                newDoc.ExportImage(option);
                

            }
            return true;
        }

        private bool ThreeExportImage(UIDocument newUIDoc, Document newDoc, FilteredElementCollector viewCollector,
            BatchFamilyExportImage_WPF batchwpf)
        {
            //throw new NotImplementedException()
            View3D view = viewCollector.First() as View3D;
            newUIDoc.ActiveView = view;
            using (Transaction trans = new Transaction(newDoc, "三维图片导出"))
            {
                trans.Start();
                view.Scale = batchwpf.Scale;
                view.DetailLevel = batchwpf.DetailLevel;
                view.DisplayStyle =batchwpf.ViewDisplayStyle;
                view.OrientTo(new XYZ(-0.577350269189626, 0.577350269189626, -0.577350269189626));
                if (batchwpf.is_HideHost) {
                    ICollection<ElementId> list = HostFilter(newDoc, view.Id);
                    if (list.Count>0) {
                        view.HideElementsTemporary(list);
                    }
                }
                trans.Commit();
            }
            
            return true;
        }

        //隐蔽主体
        private ICollection<ElementId> HostFilter(Document doc, ElementId viewId)
        {
            ICollection<ElementId> hostList = new List<ElementId>();

            FilteredElementCollector collector = new FilteredElementCollector(doc, viewId);
            collector.OfCategory(BuiltInCategory.OST_Walls).OfClass(typeof(Wall));
            if (collector.Count() > 0)
            {
                foreach (Element ele in collector)
                {
                    hostList.Add(ele.Id);
                }
            }
            collector = new FilteredElementCollector(doc, viewId);
            collector.OfCategory(BuiltInCategory.OST_Roofs).OfClass(typeof(RoofBase));
            if (collector.Count() > 0)
            {
                foreach (Element ele in collector)
                {
                    hostList.Add(ele.Id);
                }
            }
            collector = new FilteredElementCollector(doc, viewId);
            collector.OfCategory(BuiltInCategory.OST_Ceilings).OfClass(typeof(Ceiling));
            if (collector.Count() > 0)
            {
                foreach (Element ele in collector)
                {
                    hostList.Add(ele.Id);
                }
            }
            collector = new FilteredElementCollector(doc, viewId);
            collector.OfCategory(BuiltInCategory.OST_Floors).OfClass(typeof(Floor));
            if (collector.Count() > 0)
            {
                foreach (Element ele in collector)
                {
                    hostList.Add(ele.Id);
                }
            }
            collector = new FilteredElementCollector(doc, viewId);
            collector.OfClass(typeof(Extrusion));
            if (collector.Count() > 0)
            {
                foreach (Element ele in collector)
                {
                    hostList.Add(ele.Id);
                }
            }
            return hostList;
        }

        /// <summary>
        /// 导出二维图片
        /// </summary>
        /// <param name="newUIDoc"></param>
        /// <param name="newDoc"></param>
        /// <returns></returns>
        private bool TwoExportImage(UIDocument newUIDoc, Document newDoc
            , BatchFamilyExportImage_WPF batchwpf)
        {
            //throw new NotImplementedException();
            FilteredElementCollector viewCollector = new FilteredElementCollector(newDoc);
            viewCollector.OfCategory(BuiltInCategory.OST_Views).OfClass(typeof(ViewPlan));
            if (viewCollector.Count() == 0) return false;
            Autodesk.Revit.DB.View view = viewCollector.First() as Autodesk.Revit.DB.View;
            newUIDoc.ActiveView = view;

            using (Transaction trans = new Transaction(newDoc, "二维图片导出"))
            {
                trans.Start();
                view.Scale = batchwpf.Scale;
                view.DetailLevel = batchwpf.DetailLevel;
                view.DisplayStyle = batchwpf.ViewDisplayStyle;
                if (batchwpf.is_HideHost)
                {
                    ICollection<ElementId> list = HostFilter(newDoc, view.Id);
                    if (list.Count > 0)
                    {
                        view.HideElementsTemporary(list);
                    }
                }
                trans.Commit();
            }
            return true;
        }

    }
}
