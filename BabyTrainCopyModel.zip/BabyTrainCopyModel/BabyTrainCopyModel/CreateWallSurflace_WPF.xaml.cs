﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB;
namespace BabyTrainCopyModel
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class CreateWallSurflace_WPF : Window
    {
        /// <summary>
        /// 传入三个参数
        /// </summary>
        /// 初始化房间
        List<Room> roomsList;

        //传入三个参数，参数列表，房间列表，类型列表
        public CreateWallSurflace_WPF(List<string> parameterList,
            List<Room> roomList,List<string> wallTypeList)
        {
            InitializeComponent();
            //传入参数
            roomsList = roomList;
            //传入参数
            parameterNameCombo.ItemsSource = parameterList;
            //传入参数
            wallTypeCombo.ItemsSource = wallTypeList;
            //this.DialogResult = false;
        }

        /// <summary>
        /// 如果参数名称选择以后应该怎样
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ParameterNameCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //获取选择的参数名称
            string paraName = parameterNameCombo.SelectedItem.ToString();
            //参数值列表
            List<string> parameterValueList = new List<string>();
            //加入全部生成按钮
            parameterValueList.Add("全部生成");
            //遍历所有房间元素
            foreach (Room room in roomsList) {

                //元素对组列表
                ParameterMap paraMap =room.ParametersMap;
                //遍历元素对组
                foreach (Parameter para in paraMap) {
                    //如果元素的定义
                    if (para.Definition.Name==paraName) {
                        //参数的HASVALUE值
                        if (para.HasValue) {
                            //初始化参数值
                            string value;
                            //如果参数化存储的值==存储的
                            if (para.StorageType == StorageType.String)
                            {
                                //元素值等于
                                value = para.AsString();
                            }
                            else {
                                //元素值等于
                                value = para.AsValueString();
                            }
                            //如果元素不包含元素，加入元素
                            if (!parameterValueList.Contains(value)) {
                                parameterValueList.Add(value);
                            }
                        }
                    }
                }
            }

            //参数值输入
            parameterValueCombo.ItemsSource = parameterValueList;
        }

        private void Enter_Click(object sender, RoutedEventArgs e)
        {
            //判断命令
            if (parameterNameCombo.SelectedItem!=null
                &&parameterValueCombo.SelectedItem!=null
                &&wallTypeCombo.SelectedItem!=null) {
                //如果对话框有错误，关闭掉
                this.DialogResult = true;
                this.Close();
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //元素的更新
            parameterNameCombo.SelectedIndex = 0;
            parameterValueCombo.SelectedIndex = 0;
            wallTypeCombo.SelectedIndex = 0;
        }
    }
}
