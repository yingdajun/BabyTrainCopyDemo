﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System.IO;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
namespace BabyTrainCopyModel
{
    //生成墙体
    //生成楼板
    //导出族图片
    //取消或者进行墙连接
    
    public class Ribbon : IExternalApplication
    {
        string AddinPath = typeof(Ribbon).Assembly.Location;
        public Result OnShutdown(UIControlledApplication application)
        {
            //throw new NotImplementedException();
            return Result.Succeeded;
        }

        public Result OnStartup(UIControlledApplication application)
        {
            string tab = "小火车工具集复现";
            application.CreateRibbonTab(tab);
            RibbonPanel panel = application.CreateRibbonPanel(tab,"工具集面板");
            PushButtonData button1 = new PushButtonData("button1", "生成楼板"
                , AddinPath,
                "BabyTrainCopyModel.CreateFloorSurflace");
            button1.ToolTip = "批量生成楼板";
            button1.LargeImage = new BitmapImage(new Uri(AddinPath.Replace("BabyTrainCopyModel.dll", "about3.ico")));

            panel.AddItem(button1);


            PushButtonData button2 = new PushButtonData("button2", "生成墙体"
                , AddinPath,
                "BabyTrainCopyModel.CreateWallSurflace");
            button2.ToolTip = "批量生成墙体";
            button2.LargeImage = new BitmapImage(new Uri(AddinPath.Replace("BabyTrainCopyModel.dll", "about2.ico")));

            panel.AddItem(button2);


            PushButtonData button3 = new PushButtonData("button3", "批量导出族图片"
                , AddinPath,
                "BabyTrainCopyModel.BatchImageExportWpf");
            button3.ToolTip = "批量导出族图片，默认是族文件所在的新创的文件夹";
            button3.LargeImage = new BitmapImage(new Uri(AddinPath.Replace("BabyTrainCopyModel.dll", "about3.ico")));

            panel.AddItem(button3);

            PushButtonData button4 = new PushButtonData("button4", "取消或者连接墙终端"
                , AddinPath,
                "BabyTrainCopyModel.WallAndDisJoin");
            button4.ToolTip = "取消或者连接墙体";
            button4.LargeImage = new BitmapImage(new Uri(AddinPath.Replace("BabyTrainCopyModel.dll", "about4.ico")));

            panel.AddItem(button4);

            return Result.Succeeded;
        }
    }
}
