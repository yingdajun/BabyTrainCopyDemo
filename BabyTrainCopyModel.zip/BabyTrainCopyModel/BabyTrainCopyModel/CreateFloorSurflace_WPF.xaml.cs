﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB;
namespace BabyTrainCopyModel
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class CreateFloorSurflace_WPF: Window
    {
        /// <summary>
        /// 传入三个参数
        /// </summary>
        List<Room> roomsList;
        public CreateFloorSurflace_WPF(List<string> parameterList,
            List<Room> roomList,List<string> floorTypeList)
        {
            InitializeComponent();
            roomsList = roomList;
            parameterNameCombo.ItemsSource = parameterList;
            floorTypeCombo.ItemsSource = floorTypeList;
            //this.DialogResult = false;
        }

        /// <summary>
        /// 当选择发生改变时应该怎样
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ParameterNameCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string paraName = parameterNameCombo.SelectedItem.ToString();
            List<string> parameterValueList = new List<string>();
            parameterValueList.Add("全部生成");
            foreach (Room room in roomsList) {

                ParameterMap paraMap =room.ParametersMap;
                foreach (Parameter para in paraMap) {
                    if (para.Definition.Name==paraName) {
                        if (para.HasValue) {
                            string value;
                            if (para.StorageType == StorageType.String)
                            {
                                value = para.AsString();
                            }
                            else {
                                value = para.AsValueString();
                            }
                            if (!parameterValueList.Contains(value)) {
                                parameterValueList.Add(value);
                            }
                        }
                    }
                }
            }

            parameterValueCombo.ItemsSource = parameterValueList;
        }

        private void Enter_Click(object sender, RoutedEventArgs e)
        {
            if (parameterNameCombo.SelectedItem!=null
                &&parameterValueCombo.SelectedItem!=null
                &&floorTypeCombo.SelectedItem!=null) {
                this.DialogResult = true;
                this.Close();
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            parameterNameCombo.SelectedIndex = 0;
            parameterValueCombo.SelectedIndex = 0;
            floorTypeCombo.SelectedIndex = 0;
        }
    }
}
