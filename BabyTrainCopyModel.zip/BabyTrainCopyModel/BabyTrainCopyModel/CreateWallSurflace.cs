﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.Attributes;
namespace BabyTrainCopyModel
{
    [Journaling(JournalingMode.UsingCommandData)]
    [Transaction(TransactionMode.Manual)]
    class CreateWallSurflace : IExternalCommand
    {
        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            //throw new NotImplementedException();
            UIDocument uidoc = commandData.Application.ActiveUIDocument;
            Document doc = uidoc.Document;
            try {

                //获取房间
                List<Element> roomList = RoomList(doc);

                if (!(roomList.Count > 0))
                {
                    message = "模型没有绘制房间";
                    return Result.Failed;
                }
                //过滤墙体
                //墙体元素
                List<Element> wallList = WallList(doc);
                if (!(wallList.Count > 0))
                {
                    message = "模型没有墙体类型";
                    return Result.Failed;
                }

                //弹出对话框,让用户选择要添加墙体的房间和墙体的类型

                List<string> createSetting = ShowDialog(roomList, wallList);
                if (!(createSetting.Count > 0))
                {
                    return Result.Cancelled;
                }

                //获取房间边界
                List<Element> roomsList = new List<Element>();
                List<List<ElementId>> wallToJoin = new List<List<ElementId>>();
                List<CurveLoop> curveLoopList = RoomBoundaryList(roomList,createSetting,out roomsList ,out wallToJoin);

                if (!(curveLoopList.Count > 0))
                {
                    message = "模型没有有效轮廓";
                    return Result.Failed;
                }

                //生成墙体面层

                WallType wt = wallList.Where(x => x.Name == createSetting[2]).First() as WallType;
                bool result = CreateSurflace(doc,curveLoopList,wt,roomsList,createSetting,wallToJoin);

            } catch {
                
            }

            return Result.Succeeded;
               
        }




        /// <summary>
        /// 过滤项目中所有的房间
        /// </summary>
        /// <param name="doc">当前项目对象</param>
        /// <returns>房间列表</returns>
        public static List<Element> RoomList(Document doc)
        {


            //throw new NotImplementedException();
            FilteredElementCollector roomCollector = new FilteredElementCollector(doc);

            roomCollector.OfCategory(BuiltInCategory.OST_Rooms).OfClass(typeof(SpatialElement));

            List<Element> roomList = roomCollector.ToList();

            return roomList;
        }


        /// <summary>
        /// 获取楼板
        /// </summary>
        /// <param name="doc"></param>
        /// <returns></returns>
        private List<Element> WallList(Document doc)
        {
            //throw new NotImplementedException();
            FilteredElementCollector wallCollector = new FilteredElementCollector(doc);

            wallCollector.OfCategory(BuiltInCategory.OST_Walls).OfClass(typeof(WallType));

            List<Element> wallList = wallCollector.ToList();

            return wallList;
        }

        //跳出一个对话框,选择要生成墙体的房间和选择的楼板面层
        private List<string> ShowDialog(List<Element> roomList, List<Element> wallTypeList)
        {

            List<string> value = new List<string>();
            //转换形式
            List<Room> roomsList = roomList.ConvertAll(x => x as Room);

            List<string> parameterName = new List<string>();

            ParameterMap paraMap = roomList.First().ParametersMap;

            foreach (Parameter para in paraMap)
            {
                parameterName.Add(para.Definition.Name);
            }
            //转换形式
            List<string> wallTypesList = wallTypeList.ConvertAll(x => x.Name);


            CreateWallSurflace_WPF wpf = new CreateWallSurflace_WPF(
                parameterName, roomsList, wallTypesList);

            if (wpf.ShowDialog() == true)
            {

                //传递元素到后台去
                value.Add(wpf.parameterNameCombo.SelectedItem.ToString());
                value.Add(wpf.parameterValueCombo.SelectedItem.ToString());
                value.Add(wpf.wallTypeCombo.SelectedItem.ToString());
                value.Add(wpf.wallHeight.Text);
                value.Add(wpf.wallBottom.Text);
                value.Add(wpf.structural.IsChecked.ToString());
                value.Add(wpf.roomBoundary.IsChecked.ToString());
                return value;
            };
            return value;
        }

        private List<CurveArray> RoomBoundaryList(List<Element> roomList, List<string> createSetting
          , out List<Element> roomToCreate,List<List<ElementId>> wallToJoin)
        {
            //获取指定房间
            List<Element> roomsList = new List<Element>();
            //
            string paraName = createSetting[0];
            //
            string paraValue = createSetting[1];

            //如果不是全部生成
            if (paraValue != "全部生成")
            {
                //遍历房间列表
                foreach (Element ele in roomList)
                {
                    //所有房间参数
                    ParameterMap paraMap = ele.ParametersMap;
                    //遍历所有的参数
                    foreach (Parameter para in paraMap)
                    {
                        if (para.Definition.Name == paraName)
                        {
                            if (para.HasValue)
                            {
                                string value;
                                if (para.StorageType == StorageType.String)
                                {
                                    value = para.AsString();
                                }
                                else
                                {
                                    value = para.AsValueString();
                                }
                                if (value == paraValue)
                                {
                                    roomsList.Add(ele);
                                }
                            }

                        }

                    }

                }
            }
            else
            {
                roomsList = roomList;
            }

            //
            List<CurveArray> curveArrayList = new List<CurveArray>();
            //
            roomToCreate = new List<Element>();
            //
            foreach (Element element in roomsList)
            {
                Room room = element as Room;
                //存储房间最大轮廓
                CurveArray ca = new CurveArray();
                //用于判断房间最大轮廓
                List<CurveLoop> curveLoopList = new List<CurveLoop>();
                //获取房间边界
                IList<IList<BoundarySegment>> roomBoundaryListList =
                    room.GetBoundarySegments(new SpatialElementBoundaryOptions());

                //获取房间所有边界
                if (roomBoundaryListList != null)
                {
                    //获取房间所有封闭曲线
                    foreach (IList<BoundarySegment> roomBoundaryList in roomBoundaryListList)
                    {
                        CurveLoop curveLoop = new CurveLoop();
                        foreach (BoundarySegment roomBoundary in roomBoundaryList)
                        {
                            curveLoop.Append(roomBoundary.GetCurve());

                        }
                        curveLoopList.Add(curveLoop);
                    }
                }
                //
                if (roomBoundaryListList.Count == 0)
                {
                    continue;
                }


                //拉伸曲线展开体积
                List<double> volumn = new List<double>();
                try
                {

                    foreach (CurveLoop curveLoop in curveLoopList)
                    {

                        IList<CurveLoop> cList = new List<CurveLoop>();

                        cList.Add(curveLoop);

                        Solid solid = GeometryCreationUtilities.
                            CreateExtrusionGeometry(cList, XYZ.BasisZ, 1);

                        volumn.Add(solid.Volume);
                    }

                }
                catch
                {
                    continue;
                }


                //体积最大的就是最大的LOOP

                CurveLoop LargeLoop = curveLoopList.ElementAt(volumn.IndexOf(volumn.Max()));

                //转换
                foreach (Curve curve in LargeLoop)
                {
                    ca.Append(curve);
                }
                //获取最大的轮廓
                curveArrayList.Add(ca);
                //
                roomToCreate.Add(element);
            }

            //
            return curveArrayList;
        }

        /// <summary>
        /// 获取边界
        /// </summary>
        /// <param name="roomList"></param>
        /// <param name="createSetting"></param>
        /// <param name="roomToCreate"></param>
        /// <param name="wallToJoin"></param>
        /// <returns></returns>
        private List<CurveLoop> RoomBoundaryList(List<Element> roomList,List<string> createSetting
            ,out List<Element> roomToCreate,out List<List<ElementId>> wallToJoin) {

            //获取指定房间
            List<Element> roomsList = new List<Element>();
            //
            string paraName = createSetting[0];
            //
            string paraValue = createSetting[1];

            //如果不是全部生成
            if (paraValue != "全部生成")
            {
                //遍历房间列表
                foreach (Element ele in roomList)
                {
                    //所有房间参数
                    ParameterMap paraMap = ele.ParametersMap;
                    //遍历所有的参数
                    foreach (Parameter para in paraMap)
                    {
                        if (para.Definition.Name == paraName)
                        {
                            if (para.HasValue)
                            {
                                string value;
                                if (para.StorageType == StorageType.String)
                                {
                                    value = para.AsString();
                                }
                                else
                                {
                                    value = para.AsValueString();
                                }
                                if (value == paraValue)
                                {
                                    roomsList.Add(ele);
                                }
                            }

                        }

                    }

                }
            }
            else
            {
                roomsList = roomList;
            }

            List<CurveLoop> curveLoopList = new List<CurveLoop>();
            roomToCreate = new List<Element>();
            wallToJoin = new List<List<ElementId>>();
            foreach (Element element in roomList) {
                Room room = element as Room;
                //获取房间边界
                IList<IList<BoundarySegment>> roomBoundayListList =
                    room.GetBoundarySegments(new SpatialElementBoundaryOptions());

                //获取房间的所有边界
                if (roomBoundayListList!=null) {

                    CurveLoop ca = new CurveLoop();
                    foreach (IList<BoundarySegment> roomBoundaryList in roomBoundayListList) {
                        ca = new CurveLoop();
                        List<ElementId> wall = new List<ElementId>();
                        foreach (BoundarySegment roomBoundary in roomBoundaryList) {
                            ca.Append(roomBoundary.GetCurve());
                            wall.Add(roomBoundary.ElementId);
                        }
                        curveLoopList.Add(ca);
                        roomToCreate.Add(element);
                        wallToJoin.Add(wall);
                    }
                   
                }
            }

            return curveLoopList;
        }


        private bool CreateSurflace(Document doc,List<CurveLoop> curveLoopList,WallType wallType, List<Element> roomsList
            , List<string> createSetting,List<List<ElementId>> wallToJoin) {
            double wallHeight = double.Parse(createSetting[3]) / 304.8;
            double wallBottom= double.Parse(createSetting[4]) / 304.8;
            bool strurctural = false;
            int boundary = 0;
            //if (createSetting[5]=="True") strurctural = true;
            //if (createSetting[6]=="True") boundary = 1;
            if (createSetting[5] == bool.TrueString) strurctural = true;
            if (createSetting[6] == bool.TrueString) boundary = 1;
            using (Transaction trans=new Transaction(doc,"生成墙体面层")) {
                trans.Start();

                //foreach (CurveArray ca in  curveArrayList)
                for(int i=0;i<curveLoopList.Count;i++)
                {
                    //IList<Curve> curveList = new List<Curve>();
                    //往内偏移一半的墙体宽度
                    //0.656167979002625/2
                    CurveLoop cLoop = CurveLoop.CreateViaOffset(curveLoopList[i], wallType.Width/2,
                        -XYZ.BasisZ);
                    for(int j=0;j<cLoop.Count();j++) {
                        //curveList.Add(cu);
                        Wall aWall=Wall.Create(doc,cLoop.ElementAt(j)
                            ,wallType.Id,roomsList[i].LevelId,wallHeight
                            ,wallBottom, false,strurctural);
                        aWall.get_Parameter(BuiltInParameter.WALL_ATTR_ROOM_BOUNDING).Set(boundary);
                        doc.Regenerate();
                        if (wallToJoin[i][j].IntegerValue>0) {
                            Element secWall = doc.GetElement(wallToJoin[i][j]);
                            JoinGeometryUtils.JoinGeometry(doc,secWall,aWall);
                        }
                    }
                   

                }
                trans.Commit();
            }
                return true;
        }
    }
}
