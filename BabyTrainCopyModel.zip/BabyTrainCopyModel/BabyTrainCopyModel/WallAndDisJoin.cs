﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
namespace BabyTrainCopyModel
{
    [Transaction(TransactionMode.Manual)]
    class WallAndDisJoin : IExternalCommand
    {
        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            //throw new NotImplementedException();
            //初始化
            UIDocument uidoc = commandData.Application.ActiveUIDocument;
            Document doc = uidoc.Document;
            //初始化墙过滤器
            ISelectionFilter wallFilter = new WallFilter();
            //这是选择需要取消或者连接的墙体
            IList<Reference> wallFilterList = uidoc.Selection.PickObjects(ObjectType.Element
                ,wallFilter,"请选择需要取消或者连接的墙体");
            //判断是否墙首尾是否连接成功
            bool join = false;
            foreach (Reference refer in wallFilterList) {
                Wall wall = doc.GetElement(refer) as Wall;
                //判断头是否连接
                if (WallUtils.IsWallJoinAllowedAtEnd(wall,0)) {
                    join = true;
                    break;
                }
                //判断尾是否连接
                if (WallUtils.IsWallJoinAllowedAtEnd(wall, 1))
                {
                    join = true;
                    break;
                }
            }
            //取消或者连接墙体
            using (Transaction transaction=new Transaction(doc,"取消或者连接墙体")) {
                transaction.Start();
                if (join) {
                    //取消
                    foreach (Reference refer in wallFilterList) {
                        Wall wall = doc.GetElement(refer) as Wall;
                        //取消墙头连接
                        WallUtils.DisallowWallJoinAtEnd(wall, 0);
                        //取消墙尾连接
                        WallUtils.DisallowWallJoinAtEnd(wall, 1);
                    }
                } else {
                    //连接
                    foreach (Reference refer in wallFilterList)
                    {
                        Wall wall = doc.GetElement(refer) as Wall;
                        //连接墙头
                        WallUtils.AllowWallJoinAtEnd(wall, 0);
                        //连接墙尾
                        WallUtils.AllowWallJoinAtEnd(wall, 1);
                    }
                }
                transaction.Commit();
            }
                return Result.Succeeded;
        }
    }
    /// <summary>
    /// 墙体过滤器
    /// </summary>
    class WallFilter : ISelectionFilter
    {
        public bool AllowElement(Element elem)
        {
            //throw new NotImplementedException();
            //判断元素是否是墙体
            if (elem is Wall) {
                return true;
            }
            return false;
        }

        public bool AllowReference(Reference reference, XYZ position)
        {
            //throw new NotImplementedException();
            return false;
        }
    }
}
